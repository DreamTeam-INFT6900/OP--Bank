/*
Author: DreamTeam
Component: AccountDetails
Description:  Displays information related to a user's account, 
including their last login timestamp, account balance, and options to pay a bill or transfer funds
*/

//Import libraries and dependencies
import moment from "moment"; //format date and time
import { FaRegMoneyBillAlt } from "react-icons/fa";
import { FaMoneyBillTransfer } from "react-icons/fa6";
import { useSelector } from "react-redux"; //select user's data from the Redux store 
import { useNavigate } from "react-router-dom"; // used to navigate to different routes

//component definition
const AccountDetails = () => {
  //select the user data from the Redux store: "auth" slice of the store.
  const { user } = useSelector((state) => state.auth);
  //get navigate function for programmatic routing within the app
  const navigate = useNavigate();

  //render component
  return (
    <div className="my-6">
      <div className="flex flex-col sm:flex-row justify-between items-center text-center sm:text-left gap-4 text-orange-500">
        <h1 className="text-xl font-bold">Account Details</h1>
        <p>
          Last Login:{" "}
          {moment(user?.lastLogin).format("MMMM Do YYYY, h:mm:ss a")}
        </p>
      </div>
      <div className="mt-6 flex flex-wrap items-center gap-6 text-white">
        <div className="border border-orange-500 rounded-md bg-orange-500 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg">
          <h1 className="text-xl font-semibold">Balance Available</h1>
          <p className="text-lg">$500,000 AUD</p>
        </div>
        <div
          className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
          onClick={() => navigate("/pay-bill")}
        >
          <h1 className="text-xl font-semibold">Pay a bill</h1>
          <FaRegMoneyBillAlt className="text-4xl" />
        </div>
        <div className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg">
          <h1 className="text-xl font-semibold">Transfer funds</h1>
          <FaMoneyBillTransfer className="text-4xl" />
        </div>
      </div>
    </div>
  );
};
//// Export the component for use in other parts of the application
export default AccountDetails;
