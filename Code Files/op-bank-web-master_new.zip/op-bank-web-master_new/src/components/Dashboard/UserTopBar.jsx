/*
Author: DreamTeam
Component: UserTopbar
Description:  This component serves as a user-friendly top bar with user-specific information and actions, 
allowing the user to manage notifications, access settings, and log out of the application.
*/

//Import libraries and dependencies
import { IoMdLogOut } from "react-icons/io";
import { Popover } from "react-tiny-popover";
import { BsPerson } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import { onLogout } from "../../features/auth/authSlice";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

//component definition
const UserTopBar = () => {
  //retrieves the dispatch function from Redux, allowing the component to dispatch actions
  //dispatches the "onLogout" action using the dispatch function
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { user } = useSelector((state) => state.auth);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
//render component
  return (
    <div className="border border-gray-300 flex flex-col sm:flex-row justify-between items-center gap-4 py-3 px-6 rounded-md bg-white shadow-md">
      <div>
        <h1 className="text-lg">Good morning, {user?.username}!</h1>
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center w-full sm:w-auto gap-6">
        <Popover
          isOpen={isPopoverOpen}
          positions={["bottom", "left"]}
          padding={15}
          reposition={false}
          onClickOutside={() => setIsPopoverOpen(false)}
          content={() => (
            <div className="bg-white shadow-md py-4 px-6 flex flex-col gap-3">
              <button className="text-left">View Notifications</button>
              <button className="text-left border-t border-gray-200 pt-3">
                My Profile
              </button>
            </div>
          )}
        >
          <button
            className="flex items-center gap-2"
            onClick={() => setIsPopoverOpen(!isPopoverOpen)}
          >
            <BsPerson className="text-2xl" />
            {user?.username}
          </button>
        </Popover>
        <button
          className="flex items-center gap-2"
          onClick={() => {
            dispatch(onLogout());
            navigate("/");
          }}
        >
          <IoMdLogOut className="text-2xl" />
          Log out
        </button>
      </div>
    </div>
  );
};

export default UserTopBar;
