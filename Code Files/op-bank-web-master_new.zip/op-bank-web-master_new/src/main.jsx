/**
 * Author: DreamTeam
 * Description:  this code initializes a React application with routing, Redux for state management, and toast notifications. 
 * It configures the necessary components and dependencies and renders the application in the HTML element with the id "root."
 */

//Import necessary libraries and dependencies
import React from "react"; // import react
import ReactDOM from "react-dom/client"; //  rendering React components into the DOM
import { ToastContainer } from "react-toastify";//Component used to display toast notifications
import "react-toastify/dist/ReactToastify.css";
import "./index.css"; // import styles for the app
import Routes from "./Routes"; // libarary for application routing

import { store } from "./app/store";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";

//Initialize the Application
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <ToastContainer />
        <Routes />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>
);
