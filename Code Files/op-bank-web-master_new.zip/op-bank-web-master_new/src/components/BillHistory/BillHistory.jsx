/*
Author: DreamTeam
Component: BillHistory
Description: The BillHistory component is responsible for rendering a section of a web page that displays a 
bill history table with a title, a "View All" button, and placeholders for bill data.
 */

//Import libraries and dependencies
import { RiHistoryFill } from "react-icons/ri";

//component definition
const BillHistory = () => {
 //render component 
  return (
    <div>
      <div className="border border-gray-300 flex justify-between items-center py-3 px-6 rounded-md bg-white shadow-md mt-8">
        <div>
          <h1 className="text-lg">Bill History | Last 6 transitions</h1>
        </div>
        <div className="flex items-center gap-6">
          <button className="flex items-center gap-2">
            <RiHistoryFill className="text-2xl" />
            View All
          </button>
        </div>
      </div>
      <div className="relative overflow-x-auto my-6">
        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
          <thead className="text-md text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">
                Bill ID
              </th>
              <th scope="col" className="px-6 py-3">
                Type
              </th>
              <th scope="col" className="px-6 py-3">
                Amount
              </th>
              <th scope="col" className="px-6 py-3">
                Paid At
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                A135343
              </th>
              <td className="px-6 py-4">Electricity</td>
              <td className="px-6 py-4">$1,000</td>
              <td className="px-6 py-4">20 January 2023</td>
            </tr>
            <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                B399121
              </th>
              <td className="px-6 py-4">Gas</td>
              <td className="px-6 py-4">$700</td>
              <td className="px-6 py-4">02 September 2023</td>
            </tr>
            <tr className="bg-white dark:bg-gray-800">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                M34343A
              </th>
              <td className="px-6 py-4">Water</td>
              <td className="px-6 py-4">$500</td>
              <td className="px-6 py-4">27 December 2023</td>
            </tr>
            <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                A135343
              </th>
              <td className="px-6 py-4">Electricity</td>
              <td className="px-6 py-4">$1,000</td>
              <td className="px-6 py-4">20 January 2023</td>
            </tr>
            <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                B399121
              </th>
              <td className="px-6 py-4">Gas</td>
              <td className="px-6 py-4">$700</td>
              <td className="px-6 py-4">02 September 2023</td>
            </tr>
            <tr className="bg-white dark:bg-gray-800">
              <th
                scope="row"
                className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
              >
                M34343A
              </th>
              <td className="px-6 py-4">Water</td>
              <td className="px-6 py-4">$500</td>
              <td className="px-6 py-4">27 December 2023</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
// Export the component for use in other parts of the application
export default BillHistory;
