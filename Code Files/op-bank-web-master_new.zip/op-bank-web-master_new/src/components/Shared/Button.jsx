/*
Author: DreamTeam
Component: Button
Description: The Button component provides a flexible way to create buttons with different visual styles and 
behavior by adjusting the provided props, making it a convenient and reusable component in the app.
*/
const Button = ({
  children,// content inside the button
  onClick,
  disabled,
  className,
  type = "submit",//button's type, with a default value of "submit."
  variant = "primary", //The button's variant, with a default value of "primary."
}) => {
  const variants = {
    primary: "bg-black hover:bg-gray-800 text-white border border-black",
    secondary:
      "bg-transparent hover:bg-black text-black border border-black hover:text-white",
  };
  //render the button
  return (
    <button
      type={type}
      className={`${variants[variant]} px-6 py-3 rounded-md focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 ease-in ${className}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export default Button;
