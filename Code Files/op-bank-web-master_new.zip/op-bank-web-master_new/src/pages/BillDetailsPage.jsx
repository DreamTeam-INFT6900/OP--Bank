/*
Author: DreamTeam
Component: BillDetailsPage
Description: This page provides an interface for viewing bill details and marking bills as paid when needed.
*/

//Import libraries and dependencies
import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import UserBar from "../components/PayBill/UserBar";
import UserTopBar from "../components/Dashboard/UserTopBar";
import Button from "../components/Shared/Button";
import TickImg from "../assets/tick.png";

const BillDetailsPage = () => {
  const [isPaid, setIsPaid] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const company = searchParams.get("company");
  const type = searchParams.get("type");
  return (
    <div className="py-10 px-10 w-full">
      <UserTopBar />
      <UserBar currentPage={`> Pay a Bill > ${company}`} />
      <div className="mt-8 border border-gray-300 bg-gray-100 rounded-md p-8">
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-xl font-bold">Bill Details</h1>
          <h1 className="text-xl font-bold">Company: {company}</h1>
        </div>
        <div className="flex justify-between items-center mt-6">
          <div className="flex flex-col gap-3">
            <p>Bill ID: ABSIIKCKCK</p>
            <p>Due Date: 11 November, 2023</p>
            <p className="capitalize">Description: {type} Bill</p>
            <p>Meter Reading: 2321</p>
            <p>Status: Unpaid</p>
            <p>Bill Amount: $400</p>
          </div>
          <div>
            {isPaid && <img src={TickImg} alt="tick" className="w-56 h-56" />}
          </div>
        </div>
      </div>
      <div className="mt-8 flex justify-between items-center gap-4">
        <Button
          variant="secondary"
          className="flex-1"
          onClick={() => navigate("/")}
        >
          Go Back
        </Button>
        {!isPaid && (
          <Button
            variant="primary"
            className="flex-1"
            onClick={() => setIsPaid(true)}
          >
            Make Payment
          </Button>
        )}
      </div>
    </div>
  );
};

export default BillDetailsPage;
