/*
Author: DreamTeam
Component: BillHistoryPage
Description: This page provides and interface for viewing and managing bill history.
*/

//Import libraries and dependencies
import { useNavigate } from "react-router-dom";
import UserTopBar from "../components/Dashboard/UserTopBar";
import Button from "../components/Shared/Button";
import UserBar from "../components/PayBill/UserBar";
import BillHistory from "../components/BillHistory/BillHistory";

const BillHistoryPage = () => {
  const navigate = useNavigate();

  return (
    <div className="py-10 px-10 w-full">
      <UserTopBar />
      <UserBar currentPage="> Pay a Bill > Bill History" />
      <BillHistory />
      <Button
        className="mt-8"
        variant="primary"
        onClick={() => navigate("/dashboard")}
      >
        Go Back
      </Button>
    </div>
  );
};

export default BillHistoryPage;
