import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../features/auth/authSlice";

// reducer is responsible for managing the authentication state in app
export const store = configureStore({
  reducer: {
    auth: authReducer,
  },
});
