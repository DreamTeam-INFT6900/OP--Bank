/*
Author: DreamTeam
Component: ChooseProvider
Description: This page provides and interface that allows users to select a bill type or 
enter a custom provider name to pay their bills.
*/

//Import necessary libraries and dependencies
import { useNavigate, useSearchParams } from "react-router-dom";
import UserTopBar from "../components/Dashboard/UserTopBar";
import Button from "../components/Shared/Button";
import UserBar from "../components/PayBill/UserBar";
import Providers from "../components/ProviderPage/Providers";
import { useState } from "react";
import { toast } from "react-toastify";

const PROVIDERS = {
  electricity: ["Aurora Energy", "Amber Electric", "Bright Spark Power"],
  gas: ["Centralian Gas", "Kleenheat Gas", "Origin Energy"],
  water: ["Alinta Water", "Aqwest", "Barwon Water"],
};

const ChooseProvider = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const type = searchParams.get("type");

  const [providerName, setProviderName] = useState("");

  return (
    <div className="py-10 px-10 w-full">
      <UserTopBar />
      <UserBar currentPage={`> Pay a Bill > ${type}`} />
      {!type && <div>Choose a bill type</div>}
      {type && <Providers data={PROVIDERS[type]} type={type} />}
      <p className="my-8 text-3xl font-bold">OR</p>
      <div className="flex md:max-w-[50vw] items-center gap-4">
        <div className="flex flex-col gap-2 flex-1">
          <label htmlFor="email" className="text-lg">
            Enter Provider Name:
          </label>
          <input
            type="text"
            id="provider"
            className="border border-gray-300 rounded-md p-3"
            placeholder="Enter your provider name"
            value={providerName}
            onChange={(e) => setProviderName(e.target.value)}
          />
        </div>
        <Button
          className="mt-8"
          variant="secondary"
          onClick={() => {
            if (providerName.trim() === "") {
              return toast.error("Please enter a provider name");
            }
            navigate(`/bill-details?company=${providerName}&type=custom`);
          }}
        >
          Pay Bill
        </Button>
      </div>
      <Button
        className="mt-8"
        variant="primary"
        onClick={() => navigate("/pay-bill")}
      >
        Go Back
      </Button>
    </div>
  );
};

export default ChooseProvider;
