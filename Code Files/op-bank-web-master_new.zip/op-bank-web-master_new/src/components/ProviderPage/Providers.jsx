/*
Author: DreamTeam
Component: Providers
Description: Allows users to choose a service provider from a list, 
and it is flexible in terms of the data it can display, making it suitable for various bill types and scenarios in the app
*/

//Import libraries and dependencies
import { useNavigate } from "react-router-dom";//routing function

//component definition
//Component that accepts two props: data and type. 
//The data prop is an array of service providers, and the type prop represents the bill type to which these providers belong
const Providers = ({ data, type }) => {
  const navigate = useNavigate();
  
  //render component
  return (
    <div className="mt-6 flex flex-wrap items-center gap-6 text-white">
      {data.map((provider, index) => (
        <div
          key={index}
          className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
          onClick={() =>
           /*route create dynamically with company name of the provider and the type */
            navigate(`/bill-details?company=${provider}&type=${type}`)
          }
        >
          <h1 className="text-xl font-semibold">{provider}</h1>
        </div>
      ))}
    </div>
  );
};
//// Export the component for use in other parts of the application
export default Providers;
