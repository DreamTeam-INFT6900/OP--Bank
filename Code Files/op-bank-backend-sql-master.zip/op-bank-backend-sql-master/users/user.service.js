﻿/**
 * Author:DreamTeam
 * Description: This module provides services related to user authentication and management. It includes functions
 * for user authentication, retrieving user data, creating new user records, and some helper functions. 
 */
const config = require("config.json");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const db = require("_helpers/db");

module.exports = {
  authenticate,
  getAll,
  getById,
  create,
};

async function authenticate({ email, password }) {
  const user = await db.User.scope("withPassword").findOne({
    where: { email },
  });

  if (!user || !(await bcrypt.compare(password, user.password)))
    throw "Username or password is incorrect";

  // authentication successful
  const token = jwt.sign({ sub: user.id }, config.secret, { expiresIn: "7d" });
  await db.User.update({ lastLogin: Date.now() }, { where: { id: user.id } });
  return { ...omitHash(user.get()), token };
}

async function getAll() {
  return await db.User.findAll();
}

async function getById(id) {
  return await getUser(id);
}

async function create(params) {
  // validate
  if (await db.User.findOne({ where: { email: params.email } })) {
    throw 'Email "' + params.email + '" already exists!';
  }

  // hash password
  if (params.password) {
    params.password = await bcrypt.hash(params.password, 10);
  }
  params.lastLogin = Date.now();
  // save user
  await db.User.create(params);

  const user = await db.User.findOne({ where: { email: params.email } });
  const token = jwt.sign({ sub: user.id }, config.secret, { expiresIn: "7d" });
  return { ...omitHash(user.get()), token };
}
// helper functions

async function getUser(id) {
  const user = await db.User.findByPk(id);
  if (!user) throw "User not found";
  return user;
}

function omitHash(user) {
  const { hash, ...userWithoutHash } = user;
  return userWithoutHash;
}
