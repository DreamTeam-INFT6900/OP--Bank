/*
Author: DreamTeam
Component: BillTypes
Description:  The BillTypes component provides a user-friendly way to select different bill types and perform actions related to those bill types, 
such as choosing a service provider or viewing bill history.
*/

//Import libraries and dependencies
import { MdElectricBolt } from "react-icons/md";
import { AiFillFire } from "react-icons/ai";
import { GiWaterDrop } from "react-icons/gi";
import { useNavigate } from "react-router-dom";

//define component
const BillTypes = () => {
  const navigate = useNavigate();
//render component
  return (
    <div className="mt-6 flex flex-wrap items-center gap-6 text-white">
      <div
        className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
        onClick={() => navigate("/choose-provider?type=electricity")}
      >
        <h1 className="text-xl font-semibold">Electricity</h1>
        <MdElectricBolt className="text-4xl" />
      </div>
      <div
        className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
        onClick={() => navigate("/choose-provider?type=gas")}
      >
        <h1 className="text-xl font-semibold">Gas</h1>
        <AiFillFire className="text-4xl" />
      </div>
      <div
        className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
        onClick={() => navigate("/choose-provider?type=water")}
      >
        <h1 className="text-xl font-semibold">Water</h1>
        <GiWaterDrop className="text-4xl" />
      </div>
      {/* View Bill History Option */}
      <div
        className="border border-gray-800 rounded-md bg-gray-800 shadow-md py-4 px-6 w-full sm:w-64 h-44 flex items-center gap-3 justify-center flex-col cursor-pointer transition-all duration-200 ease-in hover:shadow-lg"
        /*navigate to the "/bill-history" route */
        onClick={() => navigate("/bill-history")}
      >
        <h1 className="text-xl font-semibold">View Bill History</h1>
      </div>
    </div>
  );
};

export default BillTypes;
