/*
Author: DreamTeam
Component: PayBillPage
Description: This page provides an interface for paying bills with a clear navigation structure and 
a button for returning to the dashboard.
*/
//Import libraries and dependencies
import { useNavigate } from "react-router-dom";
import UserTopBar from "../components/Dashboard/UserTopBar";
import BillTypes from "../components/PayBill/BillTypes";
import Button from "../components/Shared/Button";
import UserBar from "../components/PayBill/UserBar";

const PayBillPage = () => {
  const navigate = useNavigate();

 //Render the page 
  return (
    <div className="py-10 px-10 w-full">
      <UserTopBar />
      <UserBar currentPage="> Pay a Bill" />
      <BillTypes />
      <Button
        className="mt-8"
        variant="primary"
        onClick={() => navigate("/dashboard")}
      >
        Go Back
      </Button>
    </div>
  );
};

export default PayBillPage;
