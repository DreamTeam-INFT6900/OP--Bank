/*"auth" slice is responsible for managing authentication-related state in a Redux store.
The slice can be combined with other slices to create a complete Redux store for managing application state. */
import { createSlice } from "@reduxjs/toolkit";

// initial state of the auth slice
const initialState = {
  user: null,
  token: null,
  isLoggedIn: false,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  // An object that contains reducer functions responsible for modifying the state 
  reducers: {
    
    //// Reducer functions are defined here
    /**: This function handles user login. It receives the current state (state) and an action (action) as parameters. 
     * It updates the state by storing the user and token in local storage and setting the isLoggedIn flag to true. */
    onLogin: (state, action) => {
      // store the user and token in the the local storage
      localStorage.setItem("user", JSON.stringify(action.payload.user));
      localStorage.setItem("token", JSON.stringify(action.payload.token));
      // update the state
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isLoggedIn = true;
    },
    /**This function handles user logout. 
     * It clears the user and token from local storage and sets the state to reflect that the user is no longer logged in. */
    onLogout: (state) => {
      // remove the user and token from the local storage
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      // update the state
      state.user = null;
      state.token = null;
      state.isLoggedIn = false;
    },
    /**This function updates the user information in the state and local storage. */
    onUpdateUser: (state, action) => {
      // update the user in the local storage
      localStorage.setItem("user", JSON.stringify(action.payload));
      // update the state
      state.user = action.payload;
    },
  },
});
//Exporting Actions and Reducer

//modify state
export const { onLogin, onLogout, onUpdateUser } = authSlice.actions;

//exported as the reducer function that will be combined with other reducers to create the Redux store
export default authSlice.reducer;
