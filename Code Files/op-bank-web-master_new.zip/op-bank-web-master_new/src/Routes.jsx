/**
 * Author: DreamTeam
 * Description: This code defines the routes and navigation structure for your application, handles user authentication, 
 * and enables layout switching based on user preferences. 
 * It also ensures that the appropriate components are rendered for different routes and authentication states.
 */

//Import necessary components and dependencies
//Components and libraries required for routing, styling, and user authentication are imported
import { Route, Routes } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import "./index.css";
import ErrorPage from "./pages/ErrorPage.jsx";
import Sidebar from "./components/Siderbar/Sidebar.jsx";
import SignInPage from "./pages/SignInPage.jsx";
import RegisterPage from "./pages/RegisterPage";
import DashboardPage from "./pages/DashboardPage";
import RegisterSuccessPage from "./pages/RegisterSuccessPage";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { onLogin, onLogout } from "./features/auth/authSlice";
import ChatBotPage from "./pages/ChatBotPage";
import PayBillPage from "./pages/PayBillPage.jsx";
import ChooseProvider from "./pages/ChooseProvider.jsx";
import BillHistoryPage from "./pages/BillHistoryPage.jsx";
import BillDetailsPage from "./pages/BillDetailsPage.jsx";

//Define main routing component
const RoutesComponent = () => {
  const dispatch = useDispatch(); //access Redux store

  const { isLoggedIn } = useSelector((state) => state.auth);

  //Control the layout position 
  //false = side bar on left, true = sidebar on right
  const [layoutPosition, setLayoutPosition] = useState(false);

 //check the user's authentication status by fetching user data from local storage and dispatching Redux actions 
  useEffect(() => {
    // fetch the user data from the local storage and set it in the redux store
    const user = JSON.parse(localStorage.getItem("user"));
    const token = JSON.parse(localStorage.getItem("token"));
    if (user && token) {
      // dispatch the action to set the user and token in the redux store
      dispatch(onLogin({ user, token }));
    } else {
      // dispatch the action to remove the user and token from the redux store
      dispatch(onLogout());
    }
  }, [dispatch]);

  //Render the Sidebar and Routes
  return (
    <div
      className={`${
        !layoutPosition ? "flex-row" : "flex-row-reverse"
      } flex gap-4`}
    >
      <Sidebar
        onLayoutSwitch={() => setLayoutPosition(!layoutPosition)}
        layoutPosition={layoutPosition}
      />
      <Routes>
        {!isLoggedIn && <Route path="/" element={<SignInPage />} />}
        {isLoggedIn && <Route path="/" element={<DashboardPage />} />}
        {isLoggedIn && <Route path="/pay-bill" element={<PayBillPage />} />}
        {isLoggedIn && (
          <Route path="/choose-provider" element={<ChooseProvider />} />
        )}
        {isLoggedIn && (
          <Route path="/bill-history" element={<BillHistoryPage />} />
        )}
        {isLoggedIn && (
          <Route path="/bill-details" element={<BillDetailsPage />} />
        )}
        {!isLoggedIn && <Route path="/signin" element={<SignInPage />} />}
        {!isLoggedIn && <Route path="/register" element={<RegisterPage />} />}
        {isLoggedIn && (
          <Route path="/register-success" element={<RegisterSuccessPage />} />
        )}
        {isLoggedIn && <Route path="/dashboard" element={<DashboardPage />} />}
        <Route path="/help" element={<ChatBotPage />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </div>
  );
};

// Export the component for use in other parts of the application
export default RoutesComponent;
