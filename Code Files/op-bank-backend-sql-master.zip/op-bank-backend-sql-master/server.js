﻿require("rootpath")(); // Set the application's root path
const express = require("express");
const app = express();
const cors = require("cors"); // Enable Cross-Origin Resource Sharing (CORS)
const bodyParser = require("body-parser");// Parse incoming request bodies
const errorHandler = require("_middleware/error-handler");// Custom error handling middleware

// Parse incoming JSON and URL-encoded form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// api routes
app.use("/users", require("./users/users.controller"));

// global error handler
app.use(errorHandler);

//test route
app.get("/", (req, res) => {
  res.send("API is working properly!");
});

// start server
const port =
  process.env.NODE_ENV === "production" ? process.env.PORT || 80 : 4000;
app.listen(port, () => console.log("Server listening on port " + port));
