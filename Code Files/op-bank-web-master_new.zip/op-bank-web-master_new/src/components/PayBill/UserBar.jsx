/*
Author: DreamTeam
Component: UserBar
Description: Provide a user bar with the current page title and balance information
*/

// Component definition
const UserBar = ({ currentPage }) => {
  return (
    /*displays the navigation bar  */
    <div className="flex flex-col sm:flex-row justify-between items-center text-center sm:text-left gap-4 text-orange-500 mt-4">
      <h1 className="text-xl font-bold capitalize">Home {currentPage}</h1>
      <p className="font-bold">Balance Available: 500,000 AUD</p>
    </div>
  );
};

export default UserBar;
