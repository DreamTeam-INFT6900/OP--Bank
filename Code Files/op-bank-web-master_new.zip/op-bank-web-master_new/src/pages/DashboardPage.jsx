
/*
Author: DreamTeam
Component: DashboardPage
Description: This component responsible for rendering the dashboard page of the app.
UserTopBar, AccountDetails, and TransactionHistory componenets are used to build the dashboard page 
and display user account information and transaction history.
*/

//Import components
import AccountDetails from "../components/Dashboard/AccountDetails";
import TransactionHistory from "../components/Dashboard/TransactionHistory";
import UserTopBar from "../components/Dashboard/UserTopBar";

const DashboardPage = () => {
  return (
    <div className="py-10 px-10 w-full">
      <UserTopBar />
      <AccountDetails />
      <TransactionHistory />
    </div>
  );
};

export default DashboardPage;
